package com.example.mobilki2

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.ActivityResultLauncher
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.mobilki2.ui.theme.Mobilki2Theme

class MainActivity : ComponentActivity() {

    companion object {
        private const val TAG = "MainActivity"
        private const val KEY_CURRENT_INDEX = "currentIndex"
        private const val KEY_ANSWERS_SHOWN = "answersShown"
        const val EXTRA_ANSWER_IS_TRUE = "com.example.mobilki2.answer_is_true"
        const val EXTRA_ANSWER_SHOWN = "com.example.mobilki2.answer_shown"
    }

    private val questions = listOf(
        Question("Canberra jest stolicą Australii?", true),
        Question("Nil jest najdłuższą rzeką świata?", true),
        Question("Amazonka przepływa przez Brazylię?", true),
        Question("Polska ma dostęp do Morza Bałtyckiego?", true),
        Question("Mount Everest znajduje się w Europie?", false)
    )

    private var currentIndex = 0
    private var answersShown = BooleanArray(5) { false }

    private lateinit var promptLauncher: ActivityResultLauncher<Intent>

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Log.d(TAG, "onCreate() called")

        // Odczytanie zapisanego stanu
        if (savedInstanceState != null) {
            currentIndex = savedInstanceState.getInt(KEY_CURRENT_INDEX, 0)
            answersShown = savedInstanceState.getBooleanArray(KEY_ANSWERS_SHOWN) ?: BooleanArray(5) { false }
            Log.d(TAG, "Restored state: currentIndex = $currentIndex")
        }

        // Rejestracja launchera dla wyniku z PromptActivity
        promptLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            if (result.resultCode == RESULT_OK) {
                val answerWasShown = result.data?.getBooleanExtra(EXTRA_ANSWER_SHOWN, false) ?: false
                if (answerWasShown) {
                    answersShown[currentIndex] = true
                    Log.d(TAG, "Answer was shown for question $currentIndex")
                }
            }
        }

        enableEdgeToEdge()
        setContent {
            Mobilki2Theme {
                QuizScreen()
            }
        }
    }

    override fun onStart() {
        super.onStart()
        Log.d(TAG, "onStart() called")
    }

    override fun onResume() {
        super.onResume()
        Log.d(TAG, "onResume() called")
    }

    override fun onPause() {
        super.onPause()
        Log.d(TAG, "onPause() called")
    }

    override fun onStop() {
        super.onStop()
        Log.d(TAG, "onStop() called")
    }

    override fun onDestroy() {
        super.onDestroy()
        Log.d(TAG, "onDestroy() called")
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        Log.d(TAG, "onSaveInstanceState() called, saving currentIndex = $currentIndex")
        outState.putInt(KEY_CURRENT_INDEX, currentIndex)
        outState.putBooleanArray(KEY_ANSWERS_SHOWN, answersShown)
    }

    private fun showPrompt() {
        val answerIsTrue = questions[currentIndex].answer
        val intent = Intent(this, PromptActivity::class.java)
        intent.putExtra(EXTRA_ANSWER_IS_TRUE, answerIsTrue)
        promptLauncher.launch(intent)
    }

    @Composable
    fun QuizScreen() {
        var questionIndex by rememberSaveable { mutableIntStateOf(currentIndex) }
        var showCheatingWarning by rememberSaveable { mutableStateOf(false) }

        Scaffold(modifier = Modifier.fillMaxSize()) { innerPadding ->
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
                    .padding(16.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                Text(
                    text = "Pytanie ${questionIndex + 1}/${questions.size}",
                    fontSize = 16.sp
                )

                Spacer(modifier = Modifier.height(16.dp))

                Text(
                    text = questions[questionIndex].text,
                    fontSize = 20.sp,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.padding(horizontal = 16.dp)
                )

                Spacer(modifier = Modifier.height(32.dp))

                Row(
                    horizontalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    Button(onClick = {
                        checkAnswer(true, questionIndex, showCheatingWarning) {
                            showCheatingWarning = it
                        }
                    }) {
                        Text("Prawda")
                    }
                    Button(onClick = {
                        checkAnswer(false, questionIndex, showCheatingWarning) {
                            showCheatingWarning = it
                        }
                    }) {
                        Text("Fałsz")
                    }
                }

                Spacer(modifier = Modifier.height(24.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceEvenly
                ) {
                    Button(onClick = {
                        questionIndex = if (questionIndex > 0) questionIndex - 1 else questions.size - 1
                        currentIndex = questionIndex
                    }) {
                        Text("Poprzednie")
                    }

                    Button(onClick = {
                        showPrompt()
                    }) {
                        Text("Podpowiedź")
                    }

                    Button(onClick = {
                        questionIndex = (questionIndex + 1) % questions.size
                        currentIndex = questionIndex
                    }) {
                        Text("Następne")
                    }
                }
            }
        }
    }

    private fun checkAnswer(userAnswer: Boolean, questionIndex: Int, showWarning: Boolean, setWarning: (Boolean) -> Unit) {
        if (answersShown[questionIndex]) {
            Toast.makeText(this, "Oszustwo! Odpowiedź do tego pytania była już pokazana!", Toast.LENGTH_SHORT).show()
        }

        val correctAnswer = questions[questionIndex].answer
        val messageResId = if (userAnswer == correctAnswer) {
            "Poprawna odpowiedź!"
        } else {
            "Niepoprawna odpowiedź!"
        }
        Toast.makeText(this, messageResId, Toast.LENGTH_SHORT).show()
    }
}

data class Question(val text: String, val answer: Boolean)

