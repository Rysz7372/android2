package com.example.mobilki2

import android.content.Intent
import android.os.Bundle
import android.util.Log
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.mobilki2.ui.theme.Mobilki2Theme

class PromptActivity : ComponentActivity() {

    companion object {
        private const val TAG = "PromptActivity"
        private const val KEY_ANSWER_SHOWN = "answerShown"
    }

    private var answerIsTrue = false
    private var answerWasShown = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Log.d(TAG, "onCreate() called")

        // Odczytanie przesłanej odpowiedzi z MainActivity
        answerIsTrue = intent.getBooleanExtra(MainActivity.EXTRA_ANSWER_IS_TRUE, false)

        // Odczytanie zapisanego stanu (czy odpowiedź była już pokazana)
        if (savedInstanceState != null) {
            answerWasShown = savedInstanceState.getBoolean(KEY_ANSWER_SHOWN, false)
        }

        enableEdgeToEdge()
        setContent {
            Mobilki2Theme {
                PromptScreen()
            }
        }
    }

    override fun onStart() {
        super.onStart()
        Log.d(TAG, "onStart() called")
    }

    override fun onResume() {
        super.onResume()
        Log.d(TAG, "onResume() called")
    }

    override fun onPause() {
        super.onPause()
        Log.d(TAG, "onPause() called")
    }

    override fun onStop() {
        super.onStop()
        Log.d(TAG, "onStop() called")
    }

    override fun onDestroy() {
        super.onDestroy()
        Log.d(TAG, "onDestroy() called")
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        Log.d(TAG, "onSaveInstanceState() called")
        outState.putBoolean(KEY_ANSWER_SHOWN, answerWasShown)
    }

    private fun setAnswerShownResult(isAnswerShown: Boolean) {
        answerWasShown = isAnswerShown
        val data = Intent()
        data.putExtra(MainActivity.EXTRA_ANSWER_SHOWN, isAnswerShown)
        setResult(RESULT_OK, data)
    }

    @Composable
    fun PromptScreen() {
        var showAnswer by rememberSaveable { mutableStateOf(answerWasShown) }

        Scaffold(modifier = Modifier.fillMaxSize()) { innerPadding ->
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
                    .padding(16.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                Text(
                    text = "Czy na pewno chcesz zobaczyć odpowiedź?",
                    fontSize = 20.sp,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.padding(horizontal = 16.dp)
                )

                Spacer(modifier = Modifier.height(24.dp))

                Button(onClick = {
                    showAnswer = true
                    setAnswerShownResult(true)
                }) {
                    Text("Pokaż odpowiedź")
                }

                Spacer(modifier = Modifier.height(24.dp))

                if (showAnswer) {
                    Text(
                        text = if (answerIsTrue) "Prawda" else "Fałsz",
                        fontSize = 24.sp,
                        textAlign = TextAlign.Center
                    )
                }

                Spacer(modifier = Modifier.height(24.dp))

                Button(onClick = {
                    finish()
                }) {
                    Text("Wróć")
                }
            }
        }
    }
}

